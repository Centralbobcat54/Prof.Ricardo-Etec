Web v2.1 Interface Guide Module
Includes:
- TarefaWebController.java
- index.html with htmx form
- fragments.html row fragment
Add Thymeleaf dependency to pom.xml and integrate into your Spring project.
