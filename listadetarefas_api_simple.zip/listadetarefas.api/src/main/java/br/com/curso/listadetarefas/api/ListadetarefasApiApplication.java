package br.com.curso.listadetarefas.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ListadetarefasApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(ListadetarefasApiApplication.class, args);
    }
}
