package br.com.curso.listadetarefas.api.controller;

import br.com.curso.listadetarefas.api.model.Tarefa;
import br.com.curso.listadetarefas.api.service.TarefaService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Comparator;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/")
public class TarefaWebController {

    private final TarefaService tarefaService;

    public TarefaWebController(TarefaService tarefaService) {
        this.tarefaService = tarefaService;
    }

    @GetMapping
    public String index(Model model) {
        var tarefasOrdenadas = tarefaService.listarTodas()
                .stream()
                .sorted(Comparator.comparing(Tarefa::getId))
                .collect(Collectors.toList());
        model.addAttribute("tarefas", tarefasOrdenadas);
        return "index";
    }

    @PostMapping("/tarefas")
    public String criarTarefa(@RequestParam String titulo, @RequestParam(required = false) String descricao, Model model) {
        Tarefa nova = new Tarefa();
        nova.setTitulo(titulo);
        nova.setDescricao(descricao == null ? "" : descricao);
        nova.setConcluida(false);
        Tarefa salva = tarefaService.salvar(nova);
        model.addAttribute("tarefa", salva);
        return "fragments :: linha-tarefa";
    }

    @DeleteMapping("/web/tarefas/{id}")
    @ResponseBody
    public ResponseEntity<Void> deletarTarefa(@PathVariable Long id) {
        tarefaService.deletarTarefa(id);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/web/tarefas/{id}/toggle")
    public String toggleTarefa(@PathVariable Long id, Model model) {
        return tarefaService.atualizarStatusTarefa(id)
                .map(tarefa -> {
                    model.addAttribute("tarefa", tarefa);
                    return "fragments :: linha-tarefa";
                })
                .orElse("");
    }

    @GetMapping("/web/tarefas/{id}/edit")
    public String getEditForm(@PathVariable Long id, Model model) {
        return tarefaService.findById(id)
                .map(tarefa -> {
                    model.addAttribute("tarefa", tarefa);
                    return "fragments :: edit-form";
                })
                .orElse("");
    }

    @PutMapping("/web/tarefas/{id}")
    public String atualizarTarefaWeb(@PathVariable Long id, @RequestParam String titulo, @RequestParam(required = false) String descricao, Model model) {
        return tarefaService.findById(id)
                .map(tarefaExistente -> {
                    tarefaExistente.setTitulo(titulo);
                    tarefaExistente.setDescricao(descricao == null ? "" : descricao);
                    Tarefa atualizada = tarefaService.salvar(tarefaExistente);
                    model.addAttribute("tarefa", atualizada);
                    return "fragments :: linha-tarefa";
                })
                .orElse("");
    }

    @GetMapping("/web/tarefas/{id}")
    public String getTarefa(@PathVariable Long id, Model model) {
        return tarefaService.findById(id)
                .map(tarefa -> {
                    model.addAttribute("tarefa", tarefa);
                    return "fragments :: linha-tarefa";
                })
                .orElse("");
    }
}
