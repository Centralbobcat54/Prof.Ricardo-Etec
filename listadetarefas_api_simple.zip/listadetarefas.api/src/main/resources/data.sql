INSERT INTO TB_TAREFAS (ID, TITULO, DESCRICAO, CONCLUIDA) VALUES (1, 'Configurar o Backend', 'Criar a entidade e o repositório da Tarefa.', TRUE);
INSERT INTO TB_TAREFAS (ID, TITULO, DESCRICAO, CONCLUIDA) VALUES (2, 'Criar a API REST', 'Desenvolver o endpoint para listar as tarefas.', FALSE);
INSERT INTO TB_TAREFAS (ID, TITULO, DESCRICAO, CONCLUIDA) VALUES (3, 'Testar a criação de tarefas', 'Verificar HTMX + Thymeleaf', FALSE);
