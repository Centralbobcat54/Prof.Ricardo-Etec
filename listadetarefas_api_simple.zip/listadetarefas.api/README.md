# listadetarefas.api (v2.1 - Simples)
Projeto de exemplo: API RESTful + Web (To-Do List) com Spring Boot, Thymeleaf e H2.

## Rodando
Requisitos: Java 21, Maven instalado.

No terminal, dentro da pasta do projeto:
```
mvn spring-boot:run
```

Acesse:
- App Web: http://localhost:8080/
- API REST: http://localhost:8080/tarefas
- H2 Console: http://localhost:8080/h2-console (usuário: sa, senha: vazio)
